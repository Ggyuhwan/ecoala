package com.ecoala.ele.mngrCboPoint.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ecoala.ele.mngrCboPoint.vo.mngrCboPointVO;

@Mapper
@Repository
public interface mngrCboPointDAO {
	
	List<mngrCboPointVO>getProduct();
	int updateProduct(String productCode);
	void insertProduct(mngrCboPointVO vo);

}
