package com.ecoala.ele.commons;

import javax.servlet.http.HttpServletResponse;

import org.mybatis.logging.Logger;
import org.mybatis.logging.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Class Name  : ErrorSettingController
 * Author      : YoonGaYoung
 * Created Date: 2023. 12. 18.
 * Version: 1.0
 * Purpose:	에러 처리 컨트롤러   
 * Description: web.xml의 에러코드와 주소를 맵핑합니다.
 */
@Controller
public class ErrorSettingController {
	
	private static Logger LOGGER = LoggerFactory.getLogger(ErrorSettingController.class);
	
	@GetMapping("error400")
	public String Error400(HttpServletResponse res, Model model) {
//      LOGGER.warn("========== ERROR 400 PAGE ==========");
		model.addAttribute("code", "ERROR_400");
		return "Error/400";
	}
	
	@GetMapping("error404")
	public String Error404(HttpServletResponse res, Model model) {
//      LOGGER.warn("========== ERROR 404 PAGE ==========");
		model.addAttribute("code", "ERROR_404");
		return "Error/404";
	}
	
	@GetMapping("error500")
	public String Error500(HttpServletResponse res, Model model) {
//      LOGGER.warn("========== ERROR 500 PAGE ==========");
		model.addAttribute("code", "ERROR_500");
		return "Error/500";
	}
	
	
}
