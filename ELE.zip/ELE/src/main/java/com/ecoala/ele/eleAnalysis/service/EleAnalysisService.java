package com.ecoala.ele.eleAnalysis.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecoala.ele.eleAnalysis.dao.IEleAnalysisDAO;
import com.ecoala.ele.eleAnalysis.vo.EleAnalysisVO;
import com.ecoala.ele.eleAnalysis.vo.WeatherAnalysisVO;



@Service
public class EleAnalysisService {

	
	@Autowired
	IEleAnalysisDAO dao;
	

	public  List<EleAnalysisVO> oneMonthEle(EleAnalysisVO user) {
		 List<EleAnalysisVO> result =dao.oneMonthEle(user);
		if(result ==null) {
			return null;	
		}
		return result;
	
}
	public  List<EleAnalysisVO> comparisonEle(EleAnalysisVO user) {
		 List<EleAnalysisVO> result =dao.comparisonEle(user);
		if(result ==null) {
			return null;	
		}
		return result;
	
}
	
	public  List<WeatherAnalysisVO> weatherList(WeatherAnalysisVO user) {
		 List<WeatherAnalysisVO> result =dao.weatherList(user);
		if(result ==null) {
			return null;	
		}
		return result;
}
	public  WeatherAnalysisVO getMemWeather(String add) {
		WeatherAnalysisVO result =dao.getMemWeather(add);
		if(result ==null) {
			return null;	
		}
		return result;
	
}
	public  List<WeatherAnalysisVO> sixEleWeather(WeatherAnalysisVO user) {
		List<WeatherAnalysisVO> result =dao.sixEleWeather(user);
		if(result ==null) {
			return null;	
		}
		return result;
	
}
	
}
	
	