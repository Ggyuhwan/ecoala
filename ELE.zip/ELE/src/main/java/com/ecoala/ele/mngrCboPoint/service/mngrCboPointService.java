package com.ecoala.ele.mngrCboPoint.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecoala.ele.mngrCboPoint.dao.mngrCboPointDAO;
import com.ecoala.ele.mngrCboPoint.vo.mngrCboPointVO;

@Service
public class mngrCboPointService {
	
	@Autowired
	mngrCboPointDAO dao;
	
	public List<mngrCboPointVO>getProduct(){
		return dao.getProduct();
	}
	
	public void updateProduct(String productCode)throws Exception{
		dao.updateProduct(productCode);
		
	
	}
	  public void insertProduct(mngrCboPointVO vo) {
	        dao.insertProduct(vo);
	    }
	
	
	
	
		

}
