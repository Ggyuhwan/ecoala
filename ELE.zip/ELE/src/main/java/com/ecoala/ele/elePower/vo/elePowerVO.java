package com.ecoala.ele.elePower.vo;

public class elePowerVO {
	private String userId;
	private String dateYear;
	private String eleYear;
	private String dateMonth;
	private String eleMonth;
	private String dateWeek;
	private String eleWeek;
	private String userWins;
	private String userLosses;
}
