package com.ecoala.ele.main.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecoala.ele.main.service.MainService;
import com.ecoala.ele.main.vo.BillVO;
import com.ecoala.ele.main.vo.CombinedVO;
import com.ecoala.ele.main.vo.EachEleVO;
import com.ecoala.ele.main.vo.EleUsageVO;
import com.ecoala.ele.main.vo.TypeEleVO;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/app/main")
public class RestMainController {
	private final MainService mainService;
	public RestMainController(MainService mainService) {
		this.mainService = mainService;
	}
	
	
	
 @PostMapping("/ele")
 public ResponseEntity<CombinedVO> combineEle (@RequestBody CombinedVO combine) throws Exception {
	 EleUsageVO result = mainService.getEleUsage(combine.getEleUsageVO());
	 TypeEleVO result2 = mainService.getTypeEle(combine.getTypeEleVO());
	 CombinedVO output = new CombinedVO(result, result2);
	 return ResponseEntity.ok(output);	 
 }
  
 
@PostMapping("/eachEle")
public ResponseEntity<?> eachEle(@RequestBody EachEleVO memId){
	try {
		Date day = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sdf.format(day);
		memId.setUseDt(date);			
		EachEleVO result = mainService.getEachEle(memId);	
		return ResponseEntity.ok(result);
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("서버오류: "+ e.getMessage());
	}
}
@PostMapping("/bill")
public ResponseEntity<?> billEle(@RequestBody String memId){
	try {
		BillVO result = mainService.getBill(memId);
		return ResponseEntity.ok(result);
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("서버오류: "+ e.getMessage());
	}
}

}
