package com.ecoala.ele.eleAnalysis.vo;

public class WeatherAnalysisVO {

	private String memId;			/** 회원번호*/
	
	
	private String menNo;			/** 구성원수*/
	private String houseType;		/** 집유형*/
	private String dtMm;			/** 월*/
	private String dayWeek;			/** 주말/평균*/
	private String avgHum;			/** 하루습도*/
	private String avgTem;			/** 하루온도*/
	
	private String weekDate;		/** 1주일*/
	private String weekPRCE;		/** 1주일 강수량*/
	private String weekHUM;			/** 1주일 습도*/
	private String weekTEM;			/** 1주일 온도*/
	
	private String sixDate;			/** 6일날짜*/
	private String sixEle;			/** 6일전력량*/
	
	
	
	public WeatherAnalysisVO() {
		
	}



	@Override
	public String toString() {
		return "WeatherAnalysisVO [memId=" + memId + ", menNo=" + menNo + ", houseType=" + houseType + ", dtMm=" + dtMm
				+ ", dayWeek=" + dayWeek + ", avgHum=" + avgHum + ", avgTem=" + avgTem + ", weekDate=" + weekDate
				+ ", weekPRCE=" + weekPRCE + ", weekHUM=" + weekHUM + ", weekTEM=" + weekTEM + ", sixDate=" + sixDate
				+ ", sixEle=" + sixEle + "]";
	}



	public WeatherAnalysisVO(String memId, String menNo, String houseType, String dtMm, String dayWeek, String avgHum,
			String avgTem, String weekDate, String weekPRCE, String weekHUM, String weekTEM, String sixDate,
			String sixEle) {
		super();
		this.memId = memId;
		this.menNo = menNo;
		this.houseType = houseType;
		this.dtMm = dtMm;
		this.dayWeek = dayWeek;
		this.avgHum = avgHum;
		this.avgTem = avgTem;
		this.weekDate = weekDate;
		this.weekPRCE = weekPRCE;
		this.weekHUM = weekHUM;
		this.weekTEM = weekTEM;
		this.sixDate = sixDate;
		this.sixEle = sixEle;
	}



	public String getMemId() {
		return memId;
	}



	public void setMemId(String memId) {
		this.memId = memId;
	}



	public String getMenNo() {
		return menNo;
	}



	public void setMenNo(String menNo) {
		this.menNo = menNo;
	}



	public String getHouseType() {
		return houseType;
	}



	public void setHouseType(String houseType) {
		this.houseType = houseType;
	}



	public String getDtMm() {
		return dtMm;
	}



	public void setDtMm(String dtMm) {
		this.dtMm = dtMm;
	}



	public String getDayWeek() {
		return dayWeek;
	}



	public void setDayWeek(String dayWeek) {
		this.dayWeek = dayWeek;
	}



	public String getAvgHum() {
		return avgHum;
	}



	public void setAvgHum(String avgHum) {
		this.avgHum = avgHum;
	}



	public String getAvgTem() {
		return avgTem;
	}



	public void setAvgTem(String avgTem) {
		this.avgTem = avgTem;
	}



	public String getWeekDate() {
		return weekDate;
	}



	public void setWeekDate(String weekDate) {
		this.weekDate = weekDate;
	}



	public String getWeekPRCE() {
		return weekPRCE;
	}



	public void setWeekPRCE(String weekPRCE) {
		this.weekPRCE = weekPRCE;
	}



	public String getWeekHUM() {
		return weekHUM;
	}



	public void setWeekHUM(String weekHUM) {
		this.weekHUM = weekHUM;
	}



	public String getWeekTEM() {
		return weekTEM;
	}



	public void setWeekTEM(String weekTEM) {
		this.weekTEM = weekTEM;
	}



	public String getSixDate() {
		return sixDate;
	}



	public void setSixDate(String sixDate) {
		this.sixDate = sixDate;
	}



	public String getSixEle() {
		return sixEle;
	}



	public void setSixEle(String sixEle) {
		this.sixEle = sixEle;
	}





}