package com.ecoala.ele.mngrCboPoint.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecoala.ele.mngrCboPoint.service.mngrCboPointService;
import com.ecoala.ele.mngrCboPoint.vo.mngrCboPointVO;

@Controller
public class mngrCboPointController {
	
	@Autowired
	private mngrCboPointService mngrCboPointService;
	
	@RequestMapping("/cboAdminView")
	public String cboAdminView(Model model) {
		List<mngrCboPointVO> cboAdminView = mngrCboPointService.getProduct();
		model.addAttribute("cboAdminView", cboAdminView);
		System.out.println(model);
		return "mngr/mngrCboPoint/cboAdminView";
	}
	
	@PostMapping("/updateDo")
	public String updateDo(String productCode) throws Exception {
		mngrCboPointService.updateProduct(productCode);
		return "redirect:/mngr/mngrCboPoint/cboAdminView";
	}
	 @PostMapping("/insertProduct")
	    @ResponseBody
	    public String insertProduct(@ModelAttribute mngrCboPointVO vo) {
		 	System.out.println(vo);
	        try {
	            // 서비스를 통해 데이터베이스에 제품 추가
	            mngrCboPointService.insertProduct(vo);
	            return "success";
	        } catch (Exception e) {
	            e.printStackTrace();
	            return "error";
	        }
	    }
	}

