package com.ecoala.ele.eleAnalysis.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ecoala.ele.eleAnalysis.vo.EleAnalysisVO;
import com.ecoala.ele.eleAnalysis.vo.WeatherAnalysisVO;



@Mapper
public interface IEleAnalysisDAO {
	public WeatherAnalysisVO getMemWeather(String add);
	public List<EleAnalysisVO> oneMonthEle(EleAnalysisVO user);
	public List<EleAnalysisVO> comparisonEle(EleAnalysisVO user);
	public List<WeatherAnalysisVO> weatherList(WeatherAnalysisVO user);
	public List<WeatherAnalysisVO> sixEleWeather(WeatherAnalysisVO user);

}
