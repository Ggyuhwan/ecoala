package com.ecoala.ele.mngrCboPoint.vo;

public class mngrCboPointVO {
	
	public mngrCboPointVO() {
	}
	
	private String userId;
	private String productCode;
	private String productId;
	private String proudctPrice;
	private String ProductImg;
	private String useYn;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProudctPrice() {
		return proudctPrice;
	}
	public void setProudctPrice(String proudctPrice) {
		this.proudctPrice = proudctPrice;
	}
	public String getProductImg() {
		return ProductImg;
	}
	public void setProductImg(String productImg) {
		ProductImg = productImg;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	@Override
	public String toString() {
		return "mngrCboPointVO [userId=" + userId + ", productCode=" + productCode + ", productId=" + productId
				+ ", proudctPrice=" + proudctPrice + ", ProductImg=" + ProductImg + ", useYn=" + useYn + "]";
	}
	public mngrCboPointVO(String userId, String productCode, String productId, String proudctPrice, String productImg,
			String useYn) {
		super();
		this.userId = userId;
		this.productCode = productCode;
		this.productId = productId;
		this.proudctPrice = proudctPrice;
		ProductImg = productImg;
		this.useYn = useYn;
	}
	
	
	
	

	
	
	

}
