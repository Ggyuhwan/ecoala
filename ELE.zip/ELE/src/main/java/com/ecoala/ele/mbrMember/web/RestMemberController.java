package com.ecoala.ele.mbrMember.web;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecoala.ele.mbrMember.service.MngMemberService;
import com.ecoala.ele.mbrMember.vo.MngMemberVO;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/app/members")
public class RestMemberController {	
	private final MngMemberService memberService;	
	private final BCryptPasswordEncoder passwordEncoder;
		
	public RestMemberController(MngMemberService memberService, BCryptPasswordEncoder passwordEncoder) {
		this.memberService = memberService;
		this.passwordEncoder = passwordEncoder;
	}
	
	@PostMapping("/userlogin")
	public ResponseEntity<MngMemberVO> login(@RequestBody MngMemberVO member, HttpSession session,
			boolean remember, String fromUrl, HttpServletResponse response, HttpServletRequest request)throws IOException{
		System.out.println(member);
		MngMemberVO login = memberService.loginMember(member);
		if(login == null) {
			return ResponseEntity.badRequest().body(null);
		}
		boolean memIdMatch = member.getUserId().equals(login.getUserId());
		boolean pwMatch = passwordEncoder.matches(member.getUserPw(), login.getUserPw());
		
		if(memIdMatch && pwMatch) {
			session.setAttribute("login", login);
			if (remember) {
				Cookie cookie = new Cookie("rememberId", login.getUserId());
				cookie.setMaxAge(60*60*24*7);
				response.addCookie(cookie);
			}else {
				Cookie cookie = new Cookie("rememberId", "");
				cookie.setMaxAge(0);
				response.addCookie(cookie);
			}
			return ResponseEntity.ok(login);
		}else {
			return ResponseEntity.badRequest().body(null);
		}
		
		
	}
}

//    @PostMapping("/register")
//    public ResponseEntity<String> register(@RequestBody MemberVO member) {
//        System.out.println(member);
//        String rawPassword = member.getMemPw();
//
//        if (rawPassword == null) {
//            return ResponseEntity.badRequest().body("Registration failed");
//        }
//
//        String encodedPassword = passwordEncoder.encode(rawPassword);
//
//        // 새로운 MemberVO 객체 생성
//        MemberVO newMember = new MemberVO();
//        newMember.setMemId(member.getMemId());
//        newMember.setMemPw(encodedPassword);
//        newMember.setMemNm(member.getMemNm());
//        newMember.setSgngCd(0); // 시군구코드
//        newMember.setAddress(member.getAddress());
//        newMember.setEmail(member.getEmail());
//
//        try {
//            memberService.registMember(newMember);
//            return ResponseEntity.ok("Registration successful");
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.badRequest().body("Registration failed");
//        }
//    }